import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentComponent } from './appointment/appointment.component';
import { AppointmentListComponent } from './appointment/appointmentList.component';
import { DoctorComponent } from './doctor/doctor.component';
import { DoctorListComponent } from './doctor/doctorList.component';


const routes: Routes = [
 
  {path: 'doctor',component:DoctorComponent},
  
  {path: 'doctor/:id',component:DoctorComponent},
  {path:'doctorList',component:DoctorListComponent},
  {path:'appointmentlist',component:AppointmentListComponent},
  {path:'apppointmentadd',component:AppointmentComponent},
  {path:'apppointmentadd/:id',component:AppointmentComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)], 
  exports: [RouterModule]
})
export class AppRoutingModule { }

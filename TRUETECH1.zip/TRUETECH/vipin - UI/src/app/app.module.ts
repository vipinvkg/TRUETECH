import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { DoctorComponent } from './doctor/doctor.component';
import { AppointmentComponent } from './appointment/appointment.component';  // its a pre defined libraray 
import { AppointmentListComponent } from './appointment/appointmentList.component';
import { DoctorListComponent } from './doctor/doctorList.component';
import { HttpServiceService } from './httpservice.service';


@NgModule({
  declarations: [   // all componenet inside the NgModule
    AppComponent, DoctorComponent,DoctorListComponent, AppointmentListComponent, AppointmentComponent,
  ],
  imports: [               // all module inside the imports
    BrowserModule,
    AppRoutingModule, FormsModule,HttpClientModule
  ],
  providers: [HttpServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }

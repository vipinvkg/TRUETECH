import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Base } from '../base.component';
import { HttpServiceService } from '../httpservice.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent extends Base {

  
  constructor(public route: ActivatedRoute, public httpservice: HttpServiceService, public router: Router) {
    super("http://localhost:8080/appointment", route, httpservice, router);
    route.params.subscribe(params => {
      this.form.data.id = params["id"];
    });
  }

  populateForm(form, data) {
    form.id = data.id;
    form.patientName = data.patientName;
    form.emailId = data.emailId;
    form.mobileNo = data.mobileNo;
    form.dob = data.dob;
    form.appointmentDate = data.appointmentDate;
    form.doctorId = data.doctorId;
    console.log('Populated Form', form);
  }
  
  parseDate(dateString: string): Date {
    if (dateString) {
      return new Date(dateString);
    }
    return null;
  }
  
}

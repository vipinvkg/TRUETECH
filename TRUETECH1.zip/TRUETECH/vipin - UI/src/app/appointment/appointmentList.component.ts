import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Base } from '../base.component';
import { HttpServiceService } from '../httpservice.service';

@Component({
  selector: 'app-appointmentList',
  templateUrl: './appointmentList.component.html'
  
})
export class AppointmentListComponent extends Base{
 constructor(public route: ActivatedRoute , public httpservice:HttpServiceService,public router : Router) {
    super("http://localhost:8080/appointment",route,httpservice, router);
  }
  
  ngOnInit() {
    this.search();
  }
  
 
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Base } from '../base.component';
import { HttpServiceService } from '../httpservice.service';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent extends Base {

  constructor(public route: ActivatedRoute, public httpservice: HttpServiceService, public router: Router) {
    super("http://localhost:8080/doc", route, httpservice, router);
    route.params.subscribe(params => {
      this.form.data.id = params["id"];
    });
  }

  populateForm(form, data) {
    form.id = data.id;
    form.name = data.name;
    form.specification = data.specification;
    form.availabilityFromTime = data.availabilityFromTime;
    form.availabilityToTime = data.availabilityToTime;
    console.log('Populated Form', form);
  }
}

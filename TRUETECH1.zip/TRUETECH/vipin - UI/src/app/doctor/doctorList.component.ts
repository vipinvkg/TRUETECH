import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Base } from '../base.component';
import { HttpServiceService } from '../httpservice.service';

@Component({
  selector: 'app-doctorList',
  templateUrl: './doctorList.component.html'
  
})
export class DoctorListComponent extends Base {

    


  constructor( public route: ActivatedRoute , public httpservice:HttpServiceService,public router : Router) {
    super("http://localhost:8080/doc",route,httpservice,router);

  }

  ngOnInit() {
    this.search();
  }
  
  
}

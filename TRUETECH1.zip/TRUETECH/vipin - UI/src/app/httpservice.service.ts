import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router'


@Injectable()

export class HttpServiceService {
  constructor(private router: Router, private httpClient: HttpClient) {

  }

  get(endpoint, callback) {
      return this.httpClient.get(endpoint).subscribe((data) => {
      console.log('Data :: ' + data);
      callback(data);

    });
  }

  post(endpoint, bean, callback) {
    return this.httpClient.post(endpoint, bean).subscribe((data) => {
      console.log(data);
      callback(data);

    }, error => {
      console.log('Error--', error);
    });
  }


}

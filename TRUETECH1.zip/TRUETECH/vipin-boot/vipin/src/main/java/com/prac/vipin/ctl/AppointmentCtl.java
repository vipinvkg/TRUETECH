package com.prac.vipin.ctl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.prac.vipin.Response;
import com.prac.vipin.dto.AppointmentDto;
import com.prac.vipin.dto.DoctorDto;
import com.prac.vipin.service.AppointmentService;
import com.prac.vipin.service.DoctorService;

@RestController
@RequestMapping(value = "/appointment")
public class AppointmentCtl {

	@Autowired
	public AppointmentService appointmentService;

	@Autowired
	public DoctorService doctorService;
	

	@PostMapping("/save")
	public Response addApp(@RequestBody AppointmentDto app) {
		System.out.println(app.getDoctorId());
		List<DoctorDto> availDoc = doctorService.allDoc();
		List<AppointmentDto> appointmentList = appointmentService.findByDate(app.getAppointmentDate());
		Response res = new Response(true);
//		AppointmentDto appointmentExist = appointmentList.stream().findFirst().get();
		if (availDoc.size() == appointmentList.size()) {
			res.setSuccess(false);
			res.addMessage("already has appointement");
			return res;
		}
		List<Integer> listOfAppDoc = new ArrayList<>();
		AppointmentDto appointmentDto = null;
		for (Iterator iterator = appointmentList.iterator(); iterator.hasNext();) {
			appointmentDto= (AppointmentDto) iterator.next();
			listOfAppDoc.add(appointmentDto.getDoctorId());
			System.out.println(appointmentDto);
		}
		
		for (int i = 0; i < availDoc.size(); i++) {
			if(!listOfAppDoc.contains(availDoc.get(i).getId())) {
				System.out.println(availDoc.get(i).getId());
				app.setDoctorId(availDoc.get(i).getId());
				res.addData(appointmentService.addApp(app));
				break;
			}
		}
		//res.addData(appointmentService.addApp(app));
		return res;
	}
	
	@GetMapping(value = "/get/{id}")
	public Response getApp(@PathVariable int id) {
		Response res = new Response(true);
		res.addData(appointmentService.findById(id));
		return res;
	}

	@GetMapping("/search")
	public Response allApp() {
		Response res = new Response(true);
		res.addData(appointmentService.allApp());
		return res;

	}

}

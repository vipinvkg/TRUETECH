package com.prac.vipin.ctl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prac.vipin.Response;
import com.prac.vipin.dto.DoctorDto;
import com.prac.vipin.service.DoctorService;

@RestController
@RequestMapping(value = "/doc")
public class DoctorCtl {

	@Autowired
	public DoctorService doctorService;

	@PostMapping(value = "/save")
	public Response addDoc(@RequestBody DoctorDto doc) {
		Response res = new Response(true);
		res.addData(doctorService.addDoc(doc));
		return res;
	}
	
	@GetMapping(value = "/get/{id}")
	public Response getDoc(@PathVariable int id) {
		Response res = new Response(true);
		res.addData(doctorService.findById(id));
		return res;
	}

	@GetMapping(value = "/search")
	public Response allDoc() {
		Response res = new Response(true);
		res.addData(doctorService.allDoc());
		return res;
	}

}

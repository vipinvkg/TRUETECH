package com.prac.vipin.dao;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.prac.vipin.dto.AppointmentDto;

public interface AppointmentRepo extends JpaRepository<AppointmentDto, Integer> {

	public List<AppointmentDto> findByAppointmentDate(Date appDate);
	
}

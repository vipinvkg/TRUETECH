package com.prac.vipin.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.prac.vipin.dto.DoctorDto;

public interface DoctorRepo extends JpaRepository<DoctorDto, Integer> {

}

package com.prac.vipin.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class AppointmentDto {

	@Id
	@GeneratedValue(generator = "nextID")
	@GenericGenerator(name = "nextID", strategy = "increment")
	private int id;
	
	@Column
	private String patientName;
	
	@Column
	private String emailId;
	
	@Column
	private String mobileNo;
	
	@Column
	private Date dob;
	
	@Column
	private Date appointmentDate;
	
	@Override
	public String toString() {
		return "AppointmentDto [id=" + id + ", patientName=" + patientName + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + ", dob=" + dob + ", appointmentDate=" + appointmentDate + ", doctorId=" + doctorId + "]";
	}

	@Column
	private int doctorId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

}

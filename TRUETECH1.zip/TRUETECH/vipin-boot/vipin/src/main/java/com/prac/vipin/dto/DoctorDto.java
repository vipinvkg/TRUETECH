package com.prac.vipin.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import org.hibernate.annotations.GenericGenerator;

@Entity
public class DoctorDto {

	@Id
	@GeneratedValue(generator = "nextID")
	@GenericGenerator(name = "nextID", strategy = "increment")
	private int id;

	@Column
	private String name;
	
	@Column
	private String specification;

	@Column
	private String availabilityToTime;

	@Column
	private String availabilityFromTime;

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAvailabilityToTime() {
		return availabilityToTime;
	}

	public void setAvailabilityToTime(String availabilityToTime) {
		this.availabilityToTime = availabilityToTime;
	}

	public String getAvailabilityFromTime() {
		return availabilityFromTime;
	}

	public void setAvailabilityFromTime(String availabilityFromTime) {
		this.availabilityFromTime = availabilityFromTime;
	}

}

package com.prac.vipin.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.prac.vipin.dao.AppointmentRepo;
import com.prac.vipin.dto.AppointmentDto;
import com.prac.vipin.dto.DoctorDto;

@Service
public class AppointmentService {

	@Autowired
	public AppointmentRepo appDao;

	@Transactional(propagation = Propagation.REQUIRED)
	public AppointmentDto addApp(AppointmentDto app) {
		return appDao.save(app);

	}

	@Transactional(readOnly = true)
	public List<AppointmentDto> allApp() {
		return appDao.findAll();

	}
	
	@Transactional(readOnly = true)
	public AppointmentDto findById(int id) {
		return appDao.findById(id).get();

	}

	@Transactional(readOnly = true)
	public List<AppointmentDto> findByDate(Date appDate) {
		return appDao.findByAppointmentDate(appDate);

	}

}

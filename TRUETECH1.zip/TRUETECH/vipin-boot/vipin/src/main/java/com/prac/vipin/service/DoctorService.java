package com.prac.vipin.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.prac.vipin.dao.DoctorRepo;
import com.prac.vipin.dto.DoctorDto;

@Service
public class DoctorService {
	
	@Autowired
	public DoctorRepo docDao;
	
	@Transactional(propagation = Propagation.REQUIRED)
	public DoctorDto addDoc(DoctorDto doc) {
		return docDao.save(doc);

	}
	
	@Transactional(readOnly = true)
	public DoctorDto findById(int id) {
		return docDao.findById(id).get();

	}
	
	@Transactional(readOnly = true)
	public List<DoctorDto> allDoc() {
		return docDao.findAll();

	}

}

package com.prac.vipin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VipinApplicationTests {

	@Test
	void contextLoads() {
	}

}
